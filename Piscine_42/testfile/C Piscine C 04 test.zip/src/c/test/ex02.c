#include <stdio.h>
#include <stdlib.h>

void ft_putnbr(int nb);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	if (!argv[1][0]) {
		return 0;
	}
	ft_putnbr(atoi(argv[1]));
	putchar('\n');
	return 0;
}

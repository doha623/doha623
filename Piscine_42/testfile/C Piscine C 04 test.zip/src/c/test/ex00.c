#include <stdio.h>
#include <string.h>

int ft_strlen(char *str);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	// 255: stop xargs
	return (int) strlen(argv[1]) == ft_strlen(argv[1]) ? 0 : 255;
}

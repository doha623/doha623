# C Piscine C 04

## test

```sh
sh src/make.sh
```

#!/bin/sh

rm -rf ex00
sh src/test/scripts/ex00.sh
mkdir -p ex00
cp src/c/source/ft_strcpy.c ex00/ft_strcpy.c

rm -rf ex01
sh src/test/scripts/ex01.sh
mkdir -p ex01
cp src/c/source/ft_strncpy.c ex01/ft_strncpy.c

rm -rf ex02
sh src/test/scripts/ex02.sh
mkdir -p ex02
cp src/c/source/ft_str_is_alpha.c ex02/ft_str_is_alpha.c

rm -rf ex03
sh src/test/scripts/ex03.sh
mkdir -p ex03
cp src/c/source/ft_str_is_numeric.c ex03/ft_str_is_numeric.c

rm -rf ex04
sh src/test/scripts/ex04.sh
mkdir -p ex04
cp src/c/source/ft_str_is_lowercase.c ex04/ft_str_is_lowercase.c

rm -rf ex05
sh src/test/scripts/ex05.sh
mkdir -p ex05
cp src/c/source/ft_str_is_uppercase.c ex05/ft_str_is_uppercase.c

rm -rf ex06
sh src/test/scripts/ex06.sh
mkdir -p ex06
cp src/c/source/ft_str_is_printable.c ex06/ft_str_is_printable.c

rm -rf ex07
sh src/test/scripts/ex07.sh
mkdir -p ex07
cp src/c/source/ft_strupcase.c ex07/ft_strupcase.c

rm -rf ex08
sh src/test/scripts/ex08.sh
mkdir -p ex08
cp src/c/source/ft_strlowcase.c ex08/ft_strlowcase.c

rm -rf ex09
sh src/test/scripts/ex09.sh
mkdir -p ex09
cp src/c/source/ft_strcapitalize.c ex09/ft_strcapitalize.c

rm -rf ex10
sh src/test/scripts/ex10.sh
mkdir -p ex10
cp src/c/source/ft_strlcpy.c ex10/ft_strlcpy.c

rm -rf ex11
sh src/test/scripts/ex11.sh
mkdir -p ex11
cp src/c/source/ft_putstr_non_printable.c ex11/ft_putstr_non_printable.c

rm -rf ex12
sh src/test/scripts/ex12.sh
mkdir -p ex12
cp src/c/source/ft_print_memory.c ex12/ft_print_memory.c

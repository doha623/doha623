#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex09.out src/c/test/ex09.c src/c/source/ft_strcapitalize.c
if [ $? -ne 0 ]; then
  echo '[ex09] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_strcapitalize.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex09] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex09-in.txt | xargs -L1 test/ex09.out | diff src/test/cases/ex09-out.txt - > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex09] FAILED - output differs'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex09] PASSED ALL TESTS'
fi

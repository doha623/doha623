#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex11.out src/c/test/ex11.c src/c/source/ft_putstr_non_printable.c
if [ $? -ne 0 ]; then
  echo '[ex11] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_putstr_non_printable.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex11] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex11-in.txt | xargs -L1 test/ex11.out | diff src/test/cases/ex11-out.txt - > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex11] FAILED - output differs'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex11] PASSED ALL TESTS'
fi

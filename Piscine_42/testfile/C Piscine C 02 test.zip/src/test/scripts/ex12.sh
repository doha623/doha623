#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex12.out src/c/test/ex12.c src/c/source/ft_print_memory.c
if [ $? -ne 0 ]; then
  echo '[ex12] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_print_memory.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex12] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex12-in.txt | xargs -L1 test/ex12.out | sed "s/.\{16\}: //" | diff src/test/cases/ex12-out.txt - > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex12] FAILED - output differs'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex12] PASSED ALL AVAILABLE TESTS - address is not checked'
fi

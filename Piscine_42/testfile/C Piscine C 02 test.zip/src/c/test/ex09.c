#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *ft_strcapitalize(char *str);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	size_t length = strlen(argv[1]);
	char *str = malloc(sizeof(char) * (length + 1));
	if (!str) {
		puts("Failed to alloc");
		return -1;
	}
	strcpy(str, argv[1]);
	char *tmp = ft_strcapitalize(str);
	puts(tmp);
	free(str);
	return str != tmp;
}

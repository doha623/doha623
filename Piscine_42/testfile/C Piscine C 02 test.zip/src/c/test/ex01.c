#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *ft_strncpy(char *dest, char *src, unsigned int n);

int main(int argc, char **argv) {
	if (argc < 4) {
		puts("Invalid args");
		return -1;
	}
	int n = atoi(argv[1]);
	if (n < 0) {
		puts("Invalid length");
		return -2;
	}
	size_t len = strlen(argv[2]) + 1;
	if (len < (size_t) n) {
		puts("Invalid buffer");
		return -3;
	}
	char *test = malloc(sizeof(char) * (len + 1));
	if (!test) {
		puts("Failed to alloc");
		return -4;
	}
	memcpy(test, argv[2], sizeof(char) * (len + 1));
	char *dest = malloc(sizeof(char) * (len + 1));
	if (!dest) {
		puts("Failed to alloc");
		free(test);
		return -5;
	}
	memcpy(dest, argv[2], sizeof(char) * (len + 1));
	strncpy(test, argv[3], n);
	int result = ft_strncpy(dest, argv[3], n) == dest && memcmp(dest, test, sizeof(char) * (len + 1)) == 0;
	free(test);
	free(dest);
	// 255: stop xargs
	return result ? 0 : 255;
}

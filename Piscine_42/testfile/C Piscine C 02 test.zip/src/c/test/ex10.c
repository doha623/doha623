#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned int ft_strlcpy(char *dest, char *src, unsigned int size);

int main(int argc, char **argv) {
	if (argc < 4) {
		puts("Invalid args");
		return -1;
	}
	int n = atoi(argv[1]);
	if (n < 0) {
		puts("Invalid length");
		return -2;
	}
	size_t len = strlen(argv[2]) + 1;
	if (len < (size_t) n) {
		puts("Invalid buffer");
		return -3;
	}
	char *test = malloc(sizeof(char) * (len + 1));
	if (!test) {
		puts("Failed to alloc");
		return -4;
	}
	memcpy(test, argv[2], sizeof(char) * (len + 1));
	char *dest = malloc(sizeof(char) * (len + 1));
	if (!dest) {
		puts("Failed to alloc");
		free(test);
		return -5;
	}
	memcpy(dest, argv[2], sizeof(char) * (len + 1));
	size_t tmp = strlcpy(test, argv[3], n);
	int result = ft_strlcpy(dest, argv[3], n) == tmp && memcmp(dest, test, sizeof(char) * (len + 1)) == 0;
	/*
	if (!result) {
		printf("n: %s\n", argv[1]);
		printf("initial buffer state: %s\n", argv[2]);
		printf("input: %s\n", argv[3]);
		printf("memcmp result: %d\n", memcmp(dest, test, sizeof(char) * (len + 1)) == 0);
		printf("return value: %zu vs %u\n", tmp, ft_strlcpy(dest, argv[3], n));
		puts("test vs dest vs init vs input");
		size_t i;
		size_t temp = strlen(argv[3]);
		for (i = 0; i < len + 1; i++) {
			printf("%4hhu vs %4hhu vs %4hhu vs %4d\n", test[i], dest[i], argv[2][i], i < temp ? argv[3][i] : 0);
		}
		putchar('\n');
	}
	// */
	free(test);
	free(dest);
	// 255: stop xargs
	return result ? 0 : 255;
	// return 0;
}

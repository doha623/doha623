#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *ft_strcpy(char *dest, char *src);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	size_t len = strlen(argv[1]) + 1;
	char *dest = malloc(sizeof(char) * len);
	int result = ft_strcpy(dest, argv[1]) == dest && memcmp(dest, argv[1], sizeof(char) * len) == 0;
	free(dest);
	// 255: stop xargs
	return result ? 0 : 255;
}

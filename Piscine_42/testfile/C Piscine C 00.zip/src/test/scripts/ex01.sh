#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex01.out src/c/test/ex01.c src/c/source/ft_print_alphabet.c
if [ $? -ne 0 ]; then
  echo '[ex01] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_print_alphabet.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex01] FAILED - norminette'
  PASSED_ALL=0
fi
test/ex01.out | diff src/test/cases/ex01.txt - > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex01] FAILED - output differs'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex01] PASSED ALL TESTS'
fi

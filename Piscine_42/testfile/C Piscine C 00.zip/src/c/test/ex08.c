#include <stdio.h>
#include <stdlib.h>

void ft_print_combn(int n);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	if (!argv[1][0]) {
		return 0;
	}
	ft_print_combn(atoi(argv[1]));
	putchar('\n');
	return 0;
}

#include <stdio.h>

void ft_putchar(char c);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	ft_putchar(argv[1][0]);
	return 0;
}

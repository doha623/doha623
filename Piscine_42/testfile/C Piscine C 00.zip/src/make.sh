#!/bin/sh

rm -rf ex00
sh src/test/scripts/ex00.sh
mkdir -p ex00
cp src/c/source/ft_putchar.c ex00/ft_putchar.c

rm -rf ex01
sh src/test/scripts/ex01.sh
mkdir -p ex01
cp src/c/source/ft_print_alphabet.c ex01/ft_print_alphabet.c

rm -rf ex02
sh src/test/scripts/ex02.sh
mkdir -p ex02
cp src/c/source/ft_print_reverse_alphabet.c ex02/ft_print_reverse_alphabet.c

rm -rf ex03
sh src/test/scripts/ex03.sh
mkdir -p ex03
cp src/c/source/ft_print_numbers.c ex03/ft_print_numbers.c

rm -rf ex04
sh src/test/scripts/ex04.sh
mkdir -p ex04
cp src/c/source/ft_is_negative.c ex04/ft_is_negative.c

rm -rf ex05
sh src/test/scripts/ex05.sh
mkdir -p ex05
cp src/c/source/ft_print_comb.c ex05/ft_print_comb.c

rm -rf ex06
sh src/test/scripts/ex06.sh
mkdir -p ex06
cp src/c/source/ft_print_comb2.c ex06/ft_print_comb2.c

rm -rf ex07
sh src/test/scripts/ex07.sh
mkdir -p ex07
cp src/c/source/ft_putnbr.c ex07/ft_putnbr.c

rm -rf ex08
sh src/test/scripts/ex08.sh
mkdir -p ex08
cp src/c/source/ft_print_combn.c ex08/ft_print_combn.c

# C Piscine C 05

## test

```sh
sh src/make.sh
```

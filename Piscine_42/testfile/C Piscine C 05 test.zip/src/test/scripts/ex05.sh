#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex05.out src/c/test/ex05.c src/c/source/ft_sqrt.c
if [ $? -ne 0 ]; then
  echo '[ex05] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_sqrt.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex05] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex05-in.txt | xargs -L1 test/ex05.out | diff src/test/cases/ex05-out.txt - > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex05] FAILED - output differs'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex05] PASSED ALL TESTS'
fi

#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex06.out src/c/test/ex06.c src/c/source/ft_is_prime.c
if [ $? -ne 0 ]; then
  echo '[ex06] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_is_prime.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex06] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex06-in.txt | xargs -L1 test/ex06.out | diff src/test/cases/ex06-out.txt - > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex06] FAILED - output differs'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex06] PASSED ALL TESTS'
fi

#!/bin/sh

rm -rf ex00
sh src/test/scripts/ex00.sh
mkdir -p ex00
cp src/c/source/ft_iterative_factorial.c ex00/ft_iterative_factorial.c

rm -rf ex01
sh src/test/scripts/ex01.sh
mkdir -p ex01
cp src/c/source/ft_recursive_factorial.c ex01/ft_recursive_factorial.c

rm -rf ex02
sh src/test/scripts/ex02.sh
mkdir -p ex02
cp src/c/source/ft_iterative_power.c ex02/ft_iterative_power.c

rm -rf ex03
sh src/test/scripts/ex03.sh
mkdir -p ex03
cp src/c/source/ft_recursive_power.c ex03/ft_recursive_power.c

rm -rf ex04
sh src/test/scripts/ex04.sh
mkdir -p ex04
cp src/c/source/ft_fibonacci.c ex04/ft_fibonacci.c

rm -rf ex05
sh src/test/scripts/ex05.sh
mkdir -p ex05
cp src/c/source/ft_sqrt.c ex05/ft_sqrt.c

rm -rf ex06
sh src/test/scripts/ex06.sh
mkdir -p ex06
cp src/c/source/ft_is_prime.c ex06/ft_is_prime.c

rm -rf ex07
sh src/test/scripts/ex07.sh
mkdir -p ex07
cp src/c/source/ft_find_next_prime.c ex07/ft_find_next_prime.c

rm -rf ex08
sh src/test/scripts/ex08.sh
mkdir -p ex08
cp src/c/source/ft_ten_queens_puzzle.c ex08/ft_ten_queens_puzzle.c

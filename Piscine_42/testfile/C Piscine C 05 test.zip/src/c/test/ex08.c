#include <stdio.h>
#include <stdlib.h>

int ft_ten_queens_puzzle(void);

int main(void) {
	printf("%d\n", ft_ten_queens_puzzle());
	return 0;
}

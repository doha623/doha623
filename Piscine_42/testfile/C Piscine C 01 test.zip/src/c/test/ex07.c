#include <stdio.h>
#include <stdlib.h>

void ft_rev_int_tab(int *tab, int size);

int main(int argc, char **argv) {
	if (argc < 2) {
		puts("Invalid args");
		return -1;
	}
	int size = argc - 1, i, *tab = malloc(sizeof(int) * size);
	if (!tab) {
		puts("Failed to alloc");
		return -2;
	}
	for (i = 0; i < size; i++) {
		tab[i] = atoi(argv[i + 1]);
	}
	printf("%d", size);
	ft_rev_int_tab(tab, size);
	for (i = 0; i < size; i++) {
		printf(" %d", tab[i]);
	}
	putchar('\n');
	free(tab);
	return 0;
}

#include <stdio.h>
#include <stdlib.h>

void ft_div_mod(int a, int b, int *div, int *mod);

int main(int argc, char **argv) {
	if (argc < 3) {
		puts("Invalid args");
		return -1;
	}
	int div, mod;
	ft_div_mod(atoi(argv[1]), atoi(argv[2]), &div, &mod);
	printf("%d %d\n", div, mod);
	return 0;
}

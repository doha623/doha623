#include <stdio.h>

void ft_ultimate_ft(int *********nbr);

int main() {
	int nbr = 0;
	int *pnbr = &nbr;
	int **ppnbr = &pnbr;
	int ***pppnbr = &ppnbr;
	int ****ppppnbr = &pppnbr;
	int *****pppppnbr = &ppppnbr;
	int ******ppppppnbr = &pppppnbr;
	int *******pppppppnbr = &ppppppnbr;
	int ********ppppppppnbr = &pppppppnbr;
	ft_ultimate_ft(&ppppppppnbr);
	return nbr != 42;
}

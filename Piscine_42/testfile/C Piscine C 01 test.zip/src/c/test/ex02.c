#include <stdio.h>

void ft_swap(int *a, int *b);

int main() {
	int a = 4, b = 2;
	ft_swap(&a, &b);
	return a != 2 || b != 4;
}

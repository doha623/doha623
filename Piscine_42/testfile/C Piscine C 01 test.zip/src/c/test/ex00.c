#include <stdio.h>

void ft_ft(int *nbr);

int main() {
	int nbr = 0;
	ft_ft(&nbr);
	return nbr != 42;
}

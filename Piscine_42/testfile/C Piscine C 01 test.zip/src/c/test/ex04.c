#include <stdio.h>
#include <stdlib.h>

void ft_ultimate_div_mod(int *a, int *b);

int main(int argc, char **argv) {
	if (argc < 3) {
		puts("Invalid args");
		return -1;
	}
	int div = atoi(argv[1]), mod = atoi(argv[2]);
	ft_ultimate_div_mod(&div, &mod);
	printf("%d %d\n", div, mod);
	return 0;
}

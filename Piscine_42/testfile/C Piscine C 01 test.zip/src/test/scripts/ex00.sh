#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex00.out src/c/test/ex00.c src/c/source/ft_ft.c
if [ $? -ne 0 ]; then
  echo '[ex00] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_ft.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex00] FAILED - norminette'
  PASSED_ALL=0
fi
test/ex00.out
if [ $? -ne 0 ]; then
  echo "[ex00] FAILED - error $?"
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex00] PASSED ALL TESTS'
fi

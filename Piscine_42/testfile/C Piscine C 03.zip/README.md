# C Piscine C 03

## test

```sh
sh src/make.sh
```

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *ft_strncat(char *dest, char *src, unsigned int nb);

int main(int argc, char **argv) {
	if (argc < 5) {
		puts("Invalid args");
		return -1;
	}
	int len = atoi(argv[1]), len1 = strlen(argv[2]), len2 = strlen(argv[3]), nb = atoi(argv[4]);
	if (len <= len1 + (nb < len2 ? nb : len2)) {
		puts("Invalid length");
		return -3;
	}
	char *test = malloc(sizeof(char *) * (len + 1));
	if (!test) {
		puts("Failed to alloc");
		return -2;
	}
	char *dest = malloc(sizeof(char *) * (len + 1));
	if (!dest) {
		puts("Failed to alloc");
		free(test);
		return -2;
	}
	memcpy(test, argv[3], len1 + 1);
	memset(test + len1, 0, len - len1);
	memcpy(dest, argv[3], len1 + 1);
	memset(dest + len1, 0, len - len1);
	char *test_result = strncat(test, argv[4], nb);
	char *dest_result = ft_strncat(dest, argv[4], nb);
	int result = test_result - test == dest_result - dest && memcmp(test, dest, sizeof(char) * (len + 2)) == 0;
	if (!result) {
		printf("nb: %d\n", nb);
		printf("dest: %s\n", argv[3]);
		printf("src: %s\n", argv[4]);
		printf("expected result: %s\n", test_result);
		printf("[[your]] result: %s\n", dest_result);
		printf("expected offset: %zd\n", test_result - test);
		printf("[[your]] offset: %zd\n", dest_result - dest);
		printf("memcmp result: %d\n", memcmp(test, dest, sizeof(char) * (len + 2)));
	}
	free(test);
	free(dest);
	// 255: stop xargs
	return result ? 0 : 255;
}

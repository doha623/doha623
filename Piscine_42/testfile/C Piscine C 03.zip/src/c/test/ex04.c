#include <stdio.h>
#include <string.h>

char *ft_strstr(char *str, char *to_find);

int main(int argc, char **argv) {
	if (argc < 3) {
		puts("Invalid args");
		return -1;
	}
	if (strstr(argv[1], argv[2]) != ft_strstr(argv[1], argv[2])) {
		printf("hatstack: %s\n", argv[1]);
		printf("needle: %s\n", argv[2]);
		if (strstr(argv[1], argv[2])) printf("from found: %s\n", strstr(argv[1], argv[2]));
		printf("expected result: %p\n", strstr(argv[1], argv[2]));
		printf("[[your]] result: %p\n", ft_strstr(argv[1], argv[2]));
	}
	// 255: stop xargs
	return strstr(argv[1], argv[2]) == ft_strstr(argv[1], argv[2]) ? 0 : 255;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int ft_strncmp(char *s1, char *s2, unsigned int n);

int main(int argc, char **argv) {
	if (argc < 4) {
		puts("Invalid args");
		return -1;
	}
	int n = atoi(argv[3]);
	int result = strncmp(argv[1], argv[2], n);
	int my_result = ft_strncmp(argv[1], argv[2], n);
	if (
		(result == 0 && my_result != 0)
		|| (result > 0 && my_result <= 0)
		|| (result < 0 && my_result >= 0)
	) {
		// 255: exit xargs
		return 255;
	}
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *ft_strcat(char *dest, char *src);

int main(int argc, char **argv) {
	if (argc < 3) {
		puts("Invalid args");
		return -1;
	}
	int len1 = strlen(argv[1]), len2 = strlen(argv[2]), len = len1 + len2;
	char *test = malloc(sizeof(char *) * (len + 2));
	if (!test) {
		puts("Failed to alloc");
		return -2;
	}
	char *dest = malloc(sizeof(char *) * (len + 2));
	if (!dest) {
		puts("Failed to alloc");
		free(test);
		return -2;
	}
	memcpy(test, argv[1], len1 + 1);
	memset(test + len1 + 1, 0, 1);
	memcpy(dest, argv[1], len1 + 1);
	memset(dest + len1 + 1, 0, 1);
	char *test_result = strcat(test, argv[2]);
	char *dest_result = ft_strcat(dest, argv[2]);
	int result = test_result - test == dest_result - dest && memcmp(test, dest, sizeof(char *) * (len + 2)) == 0;
	if (!result) {
		printf("dest: %s\n", argv[1]);
		printf("src: %s\n", argv[2]);
		printf("expected result: %s\n", test_result);
		printf("[[your]] result: %s\n", dest_result);
		printf("expected offset: %zd\n", test_result - test);
		printf("[[your]] offset: %zd\n", dest_result - dest);
		printf("memcmp result: %d\n", memcmp(test, dest, sizeof(char *) * (len + 2)));
	}
	free(test);
	free(dest);
	// 255: stop xargs
	return result ? 0 : 255;
}

#include <stdio.h>
#include <string.h>

int ft_strcmp(char *s1, char *s2);

int main(int argc, char **argv) {
	if (argc < 3) {
		puts("Invalid args");
		return -1;
	}
	int result = strcmp(argv[1], argv[2]);
	int my_result = ft_strcmp(argv[1], argv[2]);
	if (
		(result == 0 && my_result != 0)
		|| (result > 0 && my_result <= 0)
		|| (result < 0 && my_result >= 0)
	) {
		// 255: exit xargs
		return 255;
	}
	return 0;
}

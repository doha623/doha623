#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex02.out src/c/test/ex02.c src/c/source/ft_strcat.c
if [ $? -ne 0 ]; then
  echo '[ex02] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_strcat.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex02] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex02.txt | xargs -L1 test/ex02.out
# 2>&1 > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex02] FAILED - error occurred'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex02] PASSED ALL TESTS'
fi

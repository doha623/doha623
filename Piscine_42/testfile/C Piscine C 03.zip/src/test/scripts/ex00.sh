#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex00.out src/c/test/ex00.c src/c/source/ft_strcmp.c
if [ $? -ne 0 ]; then
  echo '[ex00] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_strcmp.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex00] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex00.txt | xargs -L1 test/ex00.out
# 2>&1 > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex00] FAILED - error occurred'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex00] PASSED ALL TESTS'
fi

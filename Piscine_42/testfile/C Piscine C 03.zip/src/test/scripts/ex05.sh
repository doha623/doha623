#!/bin/sh

PASSED_ALL=1

gcc -Wall -Wextra -Werror -o test/ex05.out src/c/test/ex05.c src/c/source/ft_strlcat.c
if [ $? -ne 0 ]; then
  echo '[ex05] FAILED - compilation failed'
  PASSED_ALL=0
fi
norminette -R CheckForbiddenSourceHeader src/c/source/ft_strlcat.c > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex05] FAILED - norminette'
  PASSED_ALL=0
fi
cat src/test/cases/ex05.txt | xargs -L1 test/ex05.out
# 2>&1 > /dev/null
if [ $? -ne 0 ]; then
  echo '[ex05] FAILED - error occurred'
  PASSED_ALL=0
fi

if [ $PASSED_ALL -eq 1 ]; then
  echo '[ex05] PASSED ALL TESTS'
fi

#ifndef FT_ABS_H
# define FT_ABS_H

# define ABS(val) val < 0 ? val * -1 : val

#endif
